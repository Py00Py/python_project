def sun(a,b):
    return a+b