str=input("enter a string")
if str==str[::-1]:
    print("yes")
else :
    print("no")