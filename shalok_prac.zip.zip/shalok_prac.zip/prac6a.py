ls =[5,7,76,8,9,74,8,78]
#slicing
print(ls[2,7,2])  #output =[76,9,8]
#sorting
print(ls.sort()) #for reverse sorting ls.sort(reverse=True)
